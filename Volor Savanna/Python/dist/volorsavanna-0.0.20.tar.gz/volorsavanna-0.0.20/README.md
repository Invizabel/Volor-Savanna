# Volor Savanna is a text adventure game
# To play: python3 -m VolorSavanna
